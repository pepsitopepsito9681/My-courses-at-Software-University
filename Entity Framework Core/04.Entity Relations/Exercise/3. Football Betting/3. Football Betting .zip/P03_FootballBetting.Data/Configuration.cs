﻿namespace P03_FootballBetting.Data
{
    public static class Configuration
    {
        public const string CONNECTION_STRING = @"Server=.; Database=Bet366; Integrated Security = true;";

    }
}
